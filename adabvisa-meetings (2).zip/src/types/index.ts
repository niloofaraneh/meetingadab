import { Role } from "@/lib/enums";
import "next-auth";

declare module "next-auth" {
  interface Session {
    user: {
      id: string;
      name: string;
      phone: string;
      role: Role;
      unitId: string | null;
      unitName: string | null;
      avatarUrl: string | null;
    };
  }
}

export type ApiResponse<T = unknown> = {
  success: boolean;
  data?: T;
  error?: string;
};
