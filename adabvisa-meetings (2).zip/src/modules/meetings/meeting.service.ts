import { db } from "@/lib/db";
import { notifyUser, notifyManyUsers } from "@/modules/notifications/notification.service";
import { formatJalaliDateTime } from "@/lib/jalali";
import { checkAttendeesAvailability } from "./availability.service";

export async function createMeetingRequest(params: {
  creatorId: string;
  title: string;
  description?: string;
  date: Date;
  endDate: Date;
  location?: string;
  attendeeIds: string[];
}) {
  const meeting = await db.meeting.create({
    data: {
      title: params.title,
      description: params.description,
      date: params.date,
      endDate: params.endDate,
      location: params.location,
      creatorId: params.creatorId,
      status: "PENDING_APPROVAL",
      attendees: {
        create: params.attendeeIds.map((userId) => ({ userId, response: "PENDING" as const }))
      }
    },
    include: { attendees: true, creator: true }
  });

  await notifyManyUsers(params.attendeeIds, {
    type: "MEETING_INVITE",
    title: `دعوت به جلسه: ${meeting.title}`,
    message: `شما به جلسه‌ی «${meeting.title}» در تاریخ ${formatJalaliDateTime(meeting.date)} دعوت شده‌اید. لطفا وضعیت حضور خود را مشخص کنید.`,
    smsText: `دعوت به جلسه «${meeting.title}» - ${formatJalaliDateTime(meeting.date)}`,
    relatedMeetingId: meeting.id
  });

  return meeting;
}

export async function respondToMeeting(params: {
  meetingId: string;
  userId: string;
  response: "ACCEPTED" | "REJECTED" | "PROPOSED_NEW_TIME";
  proposedDate?: Date;
  proposedEndDate?: Date;
  note?: string;
}) {
  const attendee = await db.meetingAttendee.update({
    where: { meetingId_userId: { meetingId: params.meetingId, userId: params.userId } },
    data: {
      response: params.response,
      proposedDate: params.proposedDate,
      proposedEndDate: params.proposedEndDate,
      note: params.note,
      respondedAt: new Date()
    },
    include: { meeting: { include: { attendees: true, creator: true } }, user: true }
  });

  const meeting = attendee.meeting;

  if (params.response === "PROPOSED_NEW_TIME") {
    await db.meeting.update({ where: { id: meeting.id }, data: { status: "RESCHEDULE_PROPOSED" } });
    await notifyUser({
      userId: meeting.creatorId,
      type: "MEETING_STATUS_CHANGE",
      title: `پیشنهاد زمان جدید برای جلسه: ${meeting.title}`,
      message: `${attendee.user.fullName} برای جلسه «${meeting.title}» زمان جایگزین پیشنهاد داد.`,
      relatedMeetingId: meeting.id
    });
  } else {
    // اگر همه پاسخ داده باشند و هیچ رد یا پیشنهادی نباشد، جلسه به‌صورت خودکار تایید می‌شود
    const allAttendees = await db.meetingAttendee.findMany({ where: { meetingId: meeting.id } });
    const allResponded = allAttendees.every((a) => a.response !== "PENDING");
    const anyRejected = allAttendees.some((a) => a.response === "REJECTED");
    const anyProposed = allAttendees.some((a) => a.response === "PROPOSED_NEW_TIME");

    if (allResponded && !anyRejected && !anyProposed) {
      await db.meeting.update({ where: { id: meeting.id }, data: { status: "CONFIRMED" } });
      await notifyUser({
        userId: meeting.creatorId,
        type: "MEETING_STATUS_CHANGE",
        title: `جلسه تایید شد: ${meeting.title}`,
        message: `همه‌ی حاضرین جلسه «${meeting.title}» حضور خود را تایید کردند و جلسه قطعی شد.`,
        relatedMeetingId: meeting.id
      });
    }
  }

  return attendee;
}

// تایید دستی جلسه توسط برگزارکننده یا مدیر (صرف‌نظر از پاسخ همه‌ی افراد)
export async function forceConfirmMeeting(meetingId: string) {
  const meeting = await db.meeting.update({
    where: { id: meetingId },
    data: { status: "CONFIRMED" },
    include: { attendees: true }
  });
  await notifyManyUsers(
    meeting.attendees.map((a) => a.userId),
    {
      type: "MEETING_STATUS_CHANGE",
      title: `جلسه قطعی شد: ${meeting.title}`,
      message: `جلسه «${meeting.title}» توسط برگزارکننده قطعی اعلام شد.`,
      relatedMeetingId: meeting.id
    }
  );
  return meeting;
}

export async function cancelMeeting(meetingId: string) {
  const meeting = await db.meeting.update({
    where: { id: meetingId },
    data: { status: "CANCELED" },
    include: { attendees: true }
  });
  await notifyManyUsers(
    meeting.attendees.map((a) => a.userId),
    {
      type: "MEETING_STATUS_CHANGE",
      title: `جلسه لغو شد: ${meeting.title}`,
      message: `جلسه «${meeting.title}» لغو شد.`,
      relatedMeetingId: meeting.id
    }
  );
  return meeting;
}

export { checkAttendeesAvailability };
