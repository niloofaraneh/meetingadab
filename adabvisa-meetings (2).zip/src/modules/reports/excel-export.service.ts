/**
 * سرویس تولید خروجی اکسل مصوبات/تسک‌ها - دقیقا با ستون‌بندی فرم G20 پایش صورتجلسات ادب‌ویزا.
 * توجه: طبق درخواست، هیچ اکسلی داخل سیستم آپلود/ذخیره نمی‌شود؛ فقط هر بار که کاربر
 * درخواست خروجی بدهد، یک فایل تازه با تاریخ و ساعت شمسی ساخته و دانلود می‌شود.
 */
import * as XLSX from "xlsx";
import { db } from "@/lib/db";
import { formatJalaliDate, formatJalaliDateTime } from "@/lib/jalali";
import { TASK_STATUS_LABELS, PRIORITY_LABELS } from "@/lib/constants";

export async function buildTasksExcelBuffer(filter?: { unitId?: string; responsibleId?: string }) {
  const tasks = await db.task.findMany({
    where: {
      responsible: filter?.unitId ? { unitId: filter.unitId } : undefined,
      responsibleId: filter?.responsibleId
    },
    include: {
      responsible: true,
      assigner: true,
      minute: { include: { meeting: true } }
    },
    orderBy: { createdAt: "asc" }
  });

  const rows = tasks.map((t, idx) => ({
    "ردیف": idx + 1,
    "شماره صورتجلسه": t.minute?.number ?? "-",
    "عنوان جلسه": t.minute?.meeting?.title ?? "-",
    "تاریخ جلسه": t.minute?.meeting ? formatJalaliDate(t.minute.meeting.date) : "-",
    "موضوع / مصوبه": t.title,
    "توضیحات": t.explanation ?? t.description ?? "",
    "مسئول پیگیری": t.responsible.fullName,
    "اساین‌کننده": t.assigner.fullName,
    "اولویت": PRIORITY_LABELS[t.priority],
    "مهلت اجرا": formatJalaliDate(t.dueDate),
    "وضعیت": TASK_STATUS_LABELS[t.status],
    "تکرار": t.isRecurring ? "دارد" : "ندارد",
    "زمان انجام": t.doneAt ? formatJalaliDate(t.doneAt) : "-",
    "تاریخ بروزرسانی": formatJalaliDate(t.updatedAt)
  }));

  const worksheet = XLSX.utils.json_to_sheet(rows, {
    header: [
      "ردیف", "شماره صورتجلسه", "عنوان جلسه", "تاریخ جلسه", "موضوع / مصوبه", "توضیحات",
      "مسئول پیگیری", "اساین‌کننده", "اولویت", "مهلت اجرا", "وضعیت", "تکرار",
      "زمان انجام", "تاریخ بروزرسانی"
    ]
  });

  worksheet["!cols"] = [
    { wch: 6 }, { wch: 16 }, { wch: 22 }, { wch: 12 }, { wch: 40 }, { wch: 30 },
    { wch: 18 }, { wch: 18 }, { wch: 10 }, { wch: 12 }, { wch: 16 }, { wch: 10 },
    { wch: 12 }, { wch: 16 }
  ];

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "پایش مصوبات");

  const buffer = XLSX.write(workbook, { type: "buffer", bookType: "xlsx" });
  return buffer as Buffer;
}

// نام فایل خروجی با تاریخ و ساعت شمسی، مطابق درخواست (بدون اکسل ازپیش‌ساخته در سیستم)
export function buildExportFileName(prefix: string) {
  const stamp = formatJalaliDateTime(new Date()).replace(/\s|:/g, "-").replace(/\//g, "");
  return `${prefix}-${stamp}.xlsx`;
}
