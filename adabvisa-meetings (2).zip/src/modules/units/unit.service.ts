import { db } from "@/lib/db";

export async function getUnitTree() {
  const units = await db.unit.findMany({
    include: { users: true, _count: { select: { users: true } } },
    orderBy: { name: "asc" }
  });

  const byParent = new Map<string | null, typeof units>();
  units.forEach((u) => {
    const key = u.parentId ?? null;
    if (!byParent.has(key)) byParent.set(key, [] as any);
    byParent.get(key)!.push(u);
  });

  function build(parentId: string | null): any[] {
    return (byParent.get(parentId) ?? []).map((u) => ({
      ...u,
      children: build(u.id)
    }));
  }

  return build(null);
}
