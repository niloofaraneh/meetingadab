/**
 * سرویس مرکزی اعلان‌ها.
 * هر اعلان بسته به تنظیمات کاربر (notifyByInApp / notifyBySms) هم داخل پنل
 * ثبت می‌شود و هم (در صورت فعال بودن) از طریق فراپیامک پیامک می‌شود.
 */
import { db } from "@/lib/db";
import { NotificationType } from "@/lib/enums";
import { sendSmsViaFarapayamak } from "./providers/sms/farapayamak.provider";

export async function notifyUser(params: {
  userId: string;
  type: NotificationType;
  title: string;
  message: string;
  smsText?: string; // متن کوتاه‌تر برای پیامک؛ اگر ندهید همان message استفاده می‌شود
  relatedMeetingId?: string;
  relatedTaskId?: string;
}) {
  const user = await db.user.findUnique({ where: { id: params.userId } });
  if (!user) return null;

  const notification = await db.notification.create({
    data: {
      userId: params.userId,
      type: params.type,
      title: params.title,
      message: params.message,
      relatedMeetingId: params.relatedMeetingId,
      relatedTaskId: params.relatedTaskId,
      channel: user.notifyBySms ? "BOTH" : "IN_APP"
    }
  });

  if (user.notifyBySms && user.phone) {
    const smsText = `${params.smsText ?? params.message}\nادب‌ویزا`;
    const result = await sendSmsViaFarapayamak(user.phone, smsText);
    await db.notification.update({
      where: { id: notification.id },
      data: { smsSent: result.ok, smsSentAt: result.ok ? new Date() : null }
    });
  }

  return notification;
}

export async function notifyManyUsers(
  userIds: string[],
  base: Omit<Parameters<typeof notifyUser>[0], "userId">
) {
  return Promise.all(userIds.map((userId) => notifyUser({ ...base, userId })));
}

export async function markNotificationRead(id: string, userId: string) {
  return db.notification.updateMany({
    where: { id, userId },
    data: { isRead: true }
  });
}

export async function getUnreadCount(userId: string) {
  return db.notification.count({ where: { userId, isRead: false } });
}
