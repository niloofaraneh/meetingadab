/**
 * این سرویس باید هر ۱ تا ۲ دقیقه یک‌بار فراخوانی شود (از طریق scripts/notification-worker.ts
 * که با node-cron روی سرور شما اجرا می‌شود، یا از طریق فراخوانی دوره‌ای آدرس
 * /api/notifications/cron توسط کرون سرور).
 *
 * منطق: برای هر جلسه‌ی تاییدشده که هنوز برگزار نشده، بررسی می‌کند که آیا اکنون
 * داخل بازه‌ی «روز قبل»، «یک ساعت قبل» یا «۵ دقیقه قبل» جلسه هستیم؛ اگر بله و
 * قبلا برای آن کاربر/جلسه/نوع یادآوری، اعلانی ارسال نشده، اعلان جدید می‌سازد.
 */
import { db } from "@/lib/db";
import { notifyUser } from "./notification.service";
import { formatJalaliDateTime } from "@/lib/jalali";
import { REMINDER_OFFSETS_MINUTES } from "@/lib/constants";
import { NotificationType } from "@/lib/enums";

const WINDOW_TOLERANCE_MINUTES = 3; // بازه‌ی تلورانس اجرای کرون (اگر هر ۲ دقیقه اجرا شود کافیست)

function isWithinWindow(targetMinutesBefore: number, minutesUntilMeeting: number) {
  return Math.abs(minutesUntilMeeting - targetMinutesBefore) <= WINDOW_TOLERANCE_MINUTES;
}

async function alreadySent(meetingId: string, userId: string, type: NotificationType) {
  const existing = await db.notification.findFirst({
    where: { relatedMeetingId: meetingId, userId, type }
  });
  return !!existing;
}

export async function runMeetingReminderSweep() {
  const now = new Date();
  const upcoming = await db.meeting.findMany({
    where: {
      status: "CONFIRMED",
      date: { gte: now }
    },
    include: { attendees: { include: { user: true } }, creator: true }
  });

  let sentCount = 0;

  for (const meeting of upcoming) {
    const minutesUntil = (meeting.date.getTime() - now.getTime()) / 60000;

    const checks: Array<{ offset: number; type: NotificationType; label: string }> = [
      { offset: REMINDER_OFFSETS_MINUTES.DAY_BEFORE, type: "MEETING_REMINDER_DAY", label: "فردا" },
      { offset: REMINDER_OFFSETS_MINUTES.ONE_HOUR, type: "MEETING_REMINDER_HOUR", label: "یک ساعت دیگر" },
      { offset: REMINDER_OFFSETS_MINUTES.FIVE_MINUTES, type: "MEETING_REMINDER_MINUTES", label: "۵ دقیقه دیگر" }
    ];

    const participantIds = [
      meeting.creatorId,
      ...meeting.attendees.filter((a) => a.response === "ACCEPTED").map((a) => a.userId)
    ];
    const uniqueParticipantIds = Array.from(new Set(participantIds));

    for (const check of checks) {
      if (!isWithinWindow(check.offset, minutesUntil)) continue;

      for (const userId of uniqueParticipantIds) {
        if (await alreadySent(meeting.id, userId, check.type)) continue;

        await notifyUser({
          userId,
          type: check.type,
          title: `یادآوری جلسه: ${meeting.title}`,
          message: `جلسه «${meeting.title}» ${check.label} (${formatJalaliDateTime(meeting.date)}) برگزار می‌شود.`,
          smsText: `یادآوری جلسه «${meeting.title}» - ${check.label} - ${formatJalaliDateTime(meeting.date)}`,
          relatedMeetingId: meeting.id
        });
        sentCount++;
      }
    }
  }

  // یادآوری تسک‌های نزدیک به مهلت (روزانه یک‌بار کافی است، اما اینجا هم در همان اسکن انجام می‌شود)
  const dueSoonTasks = await db.task.findMany({
    where: {
      doneAt: null,
      dueDate: { gte: now }
    },
    include: { responsible: true }
  });

  for (const task of dueSoonTasks) {
    const daysUntil = Math.ceil((task.dueDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    if (daysUntil !== 1) continue; // فقط یک روز مانده به مهلت یادآوری تسک می‌فرستیم

    const already = await db.notification.findFirst({
      where: { relatedTaskId: task.id, userId: task.responsibleId, type: "TASK_DUE_SOON" }
    });
    if (already) continue;

    await notifyUser({
      userId: task.responsibleId,
      type: "TASK_DUE_SOON",
      title: `یادآوری مهلت تسک: ${task.title}`,
      message: `فردا مهلت انجام تسک «${task.title}» به پایان می‌رسد.`,
      smsText: `فردا مهلت تسک «${task.title}» به پایان می‌رسد.`,
      relatedTaskId: task.id
    });
    sentCount++;
  }

  return { sentCount, checkedMeetings: upcoming.length, checkedTasks: dueSoonTasks.length };
}
