/**
 * پرووایدر اعلان داخل‌پنلی (In-App) - رکورد اعلان در دیتابیس ذخیره می‌شود
 * و در زنگوله‌ی اعلان‌های پنل کاربر (Topbar) نمایش داده می‌شود.
 */
import { db } from "@/lib/db";
import { NotificationType } from "@/lib/enums";

export async function createInAppNotification(params: {
  userId: string;
  type: NotificationType;
  title: string;
  message: string;
  relatedMeetingId?: string;
  relatedTaskId?: string;
}) {
  return db.notification.create({
    data: {
      userId: params.userId,
      type: params.type,
      title: params.title,
      message: params.message,
      relatedMeetingId: params.relatedMeetingId,
      relatedTaskId: params.relatedTaskId,
      channel: "IN_APP"
    }
  });
}
