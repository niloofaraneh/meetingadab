/**
 * پرووایدر ارسال پیامک از طریق پنل فراپیامک (farapayamak.ir)
 *
 * طبق مستندات رسمی وب‌سرویس فراپیامک، متد ساده‌ی ارسال تکی/گروهی
 * "SendSimpleSMS" است که از طریق وب‌سرویس REST زیر قابل فراخوانی است:
 *   POST https://rest.payamak-panel.com/api/SendSMS/SendSMS
 *   body: { username, password, to, from, text, isflash }
 *
 * پارامترهای ورودی رسمی (مطابق مستندات):
 *   UserName, PassWord, From (شماره فرستنده), To (آرایه شماره‌ها)، Text، IsFlash
 *
 * مقدار بازگشتی یک RecId عددی است؛ کدهای خطای رایج:
 *   0: اعتبار کافی نیست | 2: اعتبار کافی نیست | 3: محدودیت ارسال روزانه
 *   4: محدودیت حجم ارسال | 5: شماره فرستنده نامعتبر | 6: سامانه در حال بروزرسانی
 *   7: متن حاوی کلمات فیلترشده
 *
 * توجه: چون این پروژه در محیط سندباکس بدون دسترسی اینترنت ساخته شده،
 * این پرووایدر تست زنده نشده است. قبل از استفاده در محیط عملیاتی حتما
 * یک بار طبق مستندات فعلی پنل خودتان (بخش وب‌سرویس در پنل فراپیامک) تطبیق دهید.
 */

type SendSmsResult = {
  ok: boolean;
  recId?: string;
  errorCode?: string;
  rawResponse?: string;
  message: string;
};

const FARAPAYAMAK_ENDPOINT = "https://rest.payamak-panel.com/api/SendSMS/SendSMS";

const ERROR_MESSAGES: Record<string, string> = {
  "0": "ارسال ناموفق",
  "1": "درخواست با موفقیت انجام شد",
  "2": "اعتبار کافی نمی‌باشد",
  "3": "محدودیت در ارسال روزانه",
  "4": "محدودیت در حجم ارسال",
  "5": "شماره فرستنده معتبر نمی‌باشد",
  "6": "سامانه در حال بروزرسانی می‌باشد",
  "7": "متن حاوی کلمات فیلتر شده می‌باشد",
  "8": "نام کاربری یا رمز عبور اشتباه است"
};

export async function sendSmsViaFarapayamak(toPhone: string, text: string): Promise<SendSmsResult> {
  const enabled = process.env.FARAPAYAMAK_ENABLED === "true";
  const username = process.env.FARAPAYAMAK_USERNAME;
  const password = process.env.FARAPAYAMAK_PASSWORD;
  const from = process.env.FARAPAYAMAK_SENDER_NUMBER;

  if (!enabled) {
    // در محیط توسعه یا وقتی پنل فعال نشده، فقط لاگ می‌کنیم تا کل جریان سیستم بدون
    // خطا کار کند. به‌محض تنظیم متغیرهای محیطی و true کردن FARAPAYAMAK_ENABLED
    // پیامک واقعی ارسال خواهد شد.
    console.log(`[SMS-DEV-MODE] to=${toPhone} text=${text}`);
    return { ok: true, message: "حالت توسعه: پیامک ارسال نشد (شبیه‌سازی شد)" };
  }

  if (!username || !password || !from) {
    return { ok: false, message: "تنظیمات پنل فراپیامک کامل نیست (فایل .env را بررسی کنید)" };
  }

  try {
    const res = await fetch(FARAPAYAMAK_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        username,
        password,
        to: toPhone,
        from,
        text,
        isflash: false
      })
    });

    const raw = await res.text();
    // پاسخ موفق معمولا یک RecId عددی طولانی است؛ در صورت خطا یک کد تک‌رقمی/دو رقمی برمی‌گردد
    const isNumericLong = /^\d{8,}$/.test(raw.trim());

    if (isNumericLong) {
      return { ok: true, recId: raw.trim(), rawResponse: raw, message: "پیامک با موفقیت ارسال شد" };
    }

    const code = raw.trim();
    return {
      ok: false,
      errorCode: code,
      rawResponse: raw,
      message: ERROR_MESSAGES[code] ?? `خطای نامشخص از پنل پیامک (پاسخ: ${raw})`
    };
  } catch (err: any) {
    return { ok: false, message: `خطا در برقراری ارتباط با پنل فراپیامک: ${err.message}` };
  }
}
