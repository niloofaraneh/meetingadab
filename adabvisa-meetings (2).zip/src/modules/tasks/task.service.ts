/**
 * سرویس تسک/مصوبات.
 * وقتی یک نفر (مدیر/سرپرست/...) برای شخص دیگری تسک می‌سازد، تسک با
 * approvalStatus=PENDING ساخته می‌شود و تا وقتی مسئولِ تسک آن را تایید نکند
 * (یا مهلت جایگزین پیشنهاد ندهد)، به‌عنوان تسک قطعی در نظر گرفته نمی‌شود.
 */
import { db } from "@/lib/db";
import { TaskPriority } from "@/lib/enums";
import { notifyUser } from "@/modules/notifications/notification.service";
import { formatJalaliDate } from "@/lib/jalali";
import { computeTaskStatus } from "@/lib/utils";

export async function createTask(params: {
  title: string;
  description?: string;
  minuteId?: string;
  responsibleId: string;
  assignerId: string;
  priority: TaskPriority;
  dueDate: Date;
  isRecurring?: boolean;
  recurrenceRule?: string;
  explanation?: string;
}) {
  const selfAssigned = params.responsibleId === params.assignerId;

  const task = await db.task.create({
    data: {
      title: params.title,
      description: params.description,
      minuteId: params.minuteId,
      responsibleId: params.responsibleId,
      assignerId: params.assignerId,
      priority: params.priority,
      dueDate: params.dueDate,
      isRecurring: params.isRecurring ?? false,
      recurrenceRule: params.recurrenceRule,
      explanation: params.explanation,
      needsApproval: !selfAssigned,
      approvalStatus: selfAssigned ? "ACCEPTED" : "PENDING",
      status: "IN_PROGRESS"
    }
  });

  if (!selfAssigned) {
    await notifyUser({
      userId: params.responsibleId,
      type: "TASK_ASSIGNED",
      title: `تسک جدید: ${task.title}`,
      message: `یک تسک جدید با مهلت ${formatJalaliDate(task.dueDate)} به شما اساین شد. لطفا آن را تایید یا زمان جایگزین پیشنهاد دهید.`,
      smsText: `تسک جدید «${task.title}» - مهلت: ${formatJalaliDate(task.dueDate)}`,
      relatedTaskId: task.id
    });
  }

  return task;
}

export async function respondToTaskAssignment(params: {
  taskId: string;
  accept: boolean;
  proposedDueDate?: Date;
  note?: string;
}) {
  const task = await db.task.update({
    where: { id: params.taskId },
    data: {
      approvalStatus: params.accept
        ? "ACCEPTED"
        : params.proposedDueDate
          ? "RESCHEDULE_PROPOSED"
          : "REJECTED",
      proposedDueDate: params.proposedDueDate,
      explanation: params.note
    },
    include: { assigner: true, responsible: true }
  });

  await notifyUser({
    userId: task.assignerId,
    type: "TASK_STATUS_CHANGE",
    title: `پاسخ به تسک: ${task.title}`,
    message: params.accept
      ? `${task.responsible.fullName} تسک «${task.title}» را پذیرفت.`
      : params.proposedDueDate
        ? `${task.responsible.fullName} برای تسک «${task.title}» مهلت جایگزین پیشنهاد داد.`
        : `${task.responsible.fullName} تسک «${task.title}» را رد کرد.`,
    relatedTaskId: task.id
  });

  return task;
}

// تایید نهاییِ مهلتِ جایگزینِ پیشنهادی توسط اساین‌کننده
export async function approveProposedDueDate(taskId: string) {
  const task = await db.task.findUniqueOrThrow({ where: { id: taskId } });
  if (!task.proposedDueDate) throw new Error("پیشنهادی برای این تسک ثبت نشده است");

  return db.task.update({
    where: { id: taskId },
    data: {
      dueDate: task.proposedDueDate,
      proposedDueDate: null,
      approvalStatus: "ACCEPTED"
    }
  });
}

export async function markTaskDone(taskId: string) {
  const task = await db.task.update({
    where: { id: taskId },
    data: { doneAt: new Date(), status: "GREEN_DONE" }
  });
  return task;
}

// این تابع باید به‌صورت دوره‌ای (مثلا هر شب) اجرا شود تا وضعیت رنگی همه‌ی تسک‌های باز به‌روز شود
export async function refreshAllTaskStatuses() {
  const openTasks = await db.task.findMany({ where: { doneAt: null } });
  let updated = 0;
  for (const t of openTasks) {
    const newStatus = computeTaskStatus(t.dueDate, t.doneAt);
    if (newStatus !== t.status) {
      await db.task.update({ where: { id: t.id }, data: { status: newStatus } });
      updated++;
    }
  }
  return { checked: openTasks.length, updated };
}
