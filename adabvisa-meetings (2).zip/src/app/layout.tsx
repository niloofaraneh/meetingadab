import type { Metadata } from "next";
import "./globals.css";
import { Providers } from "./providers";
import { APP_NAME } from "@/lib/constants";

export const metadata: Metadata = {
  title: APP_NAME,
  description: "سامانه مدیریت جلسات، صورتجلسات و مصوبات سازمانی ادب‌ویزا",
  icons: { icon: "/favicon.svg" }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <body>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
