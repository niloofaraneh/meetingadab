import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/session";
import { respondToMeeting } from "@/modules/meetings/meeting.service";
import { z } from "zod";

const schema = z.object({
  response: z.enum(["ACCEPTED", "REJECTED", "PROPOSED_NEW_TIME"]),
  proposedDate: z.string().optional(),
  proposedEndDate: z.string().optional(),
  note: z.string().optional()
});

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });

  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ success: false, error: parsed.error.message }, { status: 400 });

  const attendee = await respondToMeeting({
    meetingId: params.id,
    userId: user.id,
    response: parsed.data.response,
    proposedDate: parsed.data.proposedDate ? new Date(parsed.data.proposedDate) : undefined,
    proposedEndDate: parsed.data.proposedEndDate ? new Date(parsed.data.proposedEndDate) : undefined,
    note: parsed.data.note
  });

  return NextResponse.json({ success: true, data: attendee });
}
