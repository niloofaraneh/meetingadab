import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });

  const minute = await db.meetingMinute.findUnique({
    where: { id: params.id },
    include: {
      meeting: { include: { attendees: { include: { user: true } }, creator: true } },
      recorder: true,
      tasks: { include: { responsible: true, assigner: true } }
    }
  });

  if (!minute) return NextResponse.json({ success: false, error: "صورتجلسه یافت نشد" }, { status: 404 });
  return NextResponse.json({ success: true, data: minute });
}
