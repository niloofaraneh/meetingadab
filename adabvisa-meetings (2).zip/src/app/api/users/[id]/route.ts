import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });

  const profile = await db.user.findUnique({
    where: { id: params.id },
    include: {
      unit: true,
      responsibleTasks: { include: { minute: { include: { meeting: true } } }, orderBy: { dueDate: "asc" } },
      createdMeetings: true
    }
  });

  if (!profile) return NextResponse.json({ success: false, error: "کاربر یافت نشد" }, { status: 404 });
  const { passwordHash, ...safe } = profile;
  return NextResponse.json({ success: true, data: safe });
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });
  if (user.id !== params.id && user.role !== "SUPER_ADMIN") {
    return NextResponse.json({ success: false, error: "دسترسی غیرمجاز" }, { status: 403 });
  }

  const body = await req.json();
  const allowed = ["fullName", "avatarUrl", "position", "bio", "notifyByInApp", "notifyBySms"];
  const data: Record<string, unknown> = {};
  for (const key of allowed) if (key in body) data[key] = body[key];

  const updated = await db.user.update({ where: { id: params.id }, data });
  const { passwordHash, ...safe } = updated;
  return NextResponse.json({ success: true, data: safe });
}
