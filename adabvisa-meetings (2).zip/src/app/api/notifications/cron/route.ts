/**
 * این endpoint برای فراخوانی از بیرون (کرون سرور، یا سرویس‌های مثل cron-job.org) طراحی شده
 * تا در صورت عدم استفاده از ورکر داخلی (scripts/notification-worker.ts)، بتوان هر ۱-۲ دقیقه
 * این آدرس را با هدر امنیتی صدا زد.
 */
import { NextRequest, NextResponse } from "next/server";
import { runMeetingReminderSweep } from "@/modules/notifications/reminder.service";

export async function POST(req: NextRequest) {
  const secret = req.headers.get("x-cron-secret");
  if (!secret || secret !== process.env.NOTIFICATION_CRON_SECRET) {
    return NextResponse.json({ success: false, error: "دسترسی غیرمجاز" }, { status: 401 });
  }
  const result = await runMeetingReminderSweep();
  return NextResponse.json({ success: true, data: result });
}
