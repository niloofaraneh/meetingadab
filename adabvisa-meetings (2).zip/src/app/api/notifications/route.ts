import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });

  const notifications = await db.notification.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: "desc" },
    take: 50
  });

  return NextResponse.json({ success: true, data: notifications });
}

export async function PATCH(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });

  const body = await req.json();
  if (body.markAllRead) {
    await db.notification.updateMany({ where: { userId: user.id, isRead: false }, data: { isRead: true } });
    return NextResponse.json({ success: true });
  }
  if (body.id) {
    await db.notification.updateMany({ where: { id: body.id, userId: user.id }, data: { isRead: true } });
    return NextResponse.json({ success: true });
  }
  return NextResponse.json({ success: false, error: "درخواست نامعتبر" }, { status: 400 });
}
