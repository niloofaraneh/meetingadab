import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/session";
import { buildTasksExcelBuffer, buildExportFileName } from "@/modules/reports/excel-export.service";

export async function GET(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });

  const unitId = req.nextUrl.searchParams.get("unitId") ?? undefined;
  const responsibleId = req.nextUrl.searchParams.get("responsibleId") ?? undefined;

  const buffer = await buildTasksExcelBuffer({ unitId, responsibleId });
  const fileName = buildExportFileName("پایش-مصوبات");

  return new NextResponse(buffer, {
    headers: {
      "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "Content-Disposition": `attachment; filename="${encodeURIComponent(fileName)}"`
    }
  });
}
