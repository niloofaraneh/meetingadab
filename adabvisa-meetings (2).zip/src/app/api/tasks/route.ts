import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { createTask } from "@/modules/tasks/task.service";
import { parseJalaliString } from "@/lib/jalali";
import { z } from "zod";

const schema = z.object({
  title: z.string().min(2),
  description: z.string().optional(),
  minuteId: z.string().optional(),
  responsibleId: z.string(),
  priority: z.enum(["LOW", "NORMAL", "HIGH", "URGENT"]),
  jalaliDueDate: z.string(),
  isRecurring: z.boolean().optional(),
  recurrenceRule: z.string().optional(),
  explanation: z.string().optional()
});

export async function GET(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });

  const scope = req.nextUrl.searchParams.get("scope") ?? "mine"; // mine | team | all

  let where: any = {};
  if (scope === "mine") {
    where = { responsibleId: user.id };
  } else if (scope === "team") {
    where = { responsible: { unitId: user.unitId } };
  } // scope=all بدون فیلتر (فقط برای نقش‌های بالا در UI نمایش داده می‌شود)

  const tasks = await db.task.findMany({
    where,
    include: { responsible: true, assigner: true, minute: { include: { meeting: true } } },
    orderBy: { dueDate: "asc" }
  });

  return NextResponse.json({ success: true, data: tasks });
}

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });

  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ success: false, error: parsed.error.message }, { status: 400 });

  const dueDate = parseJalaliString(parsed.data.jalaliDueDate);
  if (!dueDate) return NextResponse.json({ success: false, error: "تاریخ مهلت نامعتبر است" }, { status: 400 });

  const task = await createTask({
    title: parsed.data.title,
    description: parsed.data.description,
    minuteId: parsed.data.minuteId,
    responsibleId: parsed.data.responsibleId,
    assignerId: user.id,
    priority: parsed.data.priority,
    dueDate,
    isRecurring: parsed.data.isRecurring,
    recurrenceRule: parsed.data.recurrenceRule,
    explanation: parsed.data.explanation
  });

  return NextResponse.json({ success: true, data: task });
}
