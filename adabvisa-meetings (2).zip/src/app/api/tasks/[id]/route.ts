import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/session";
import { db } from "@/lib/db";
import {
  respondToTaskAssignment,
  approveProposedDueDate,
  markTaskDone
} from "@/modules/tasks/task.service";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });

  const task = await db.task.findUnique({
    where: { id: params.id },
    include: { responsible: true, assigner: true, minute: { include: { meeting: true } } }
  });
  if (!task) return NextResponse.json({ success: false, error: "تسک یافت نشد" }, { status: 404 });
  return NextResponse.json({ success: true, data: task });
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });

  const body = await req.json();

  if (body.action === "respond") {
    const task = await respondToTaskAssignment({
      taskId: params.id,
      accept: body.accept,
      proposedDueDate: body.proposedDueDate ? new Date(body.proposedDueDate) : undefined,
      note: body.note
    });
    return NextResponse.json({ success: true, data: task });
  }

  if (body.action === "approveProposed") {
    const task = await approveProposedDueDate(params.id);
    return NextResponse.json({ success: true, data: task });
  }

  if (body.action === "markDone") {
    const task = await markTaskDone(params.id);
    return NextResponse.json({ success: true, data: task });
  }

  return NextResponse.json({ success: false, error: "اکشن نامعتبر" }, { status: 400 });
}
