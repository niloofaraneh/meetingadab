import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { canViewOrgWideReports } from "@/lib/permissions";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });

  const orgWide = canViewOrgWideReports(user);
  const taskWhere = orgWide ? {} : { responsible: { unitId: user.unitId } };
  const meetingWhere = orgWide
    ? {}
    : { OR: [{ creatorId: user.id }, { attendees: { some: { userId: user.id } } }] };

  const [totalMeetings, confirmedMeetings, pendingMeetings, totalTasks, doneTasks, overdueTasks, dueSoonTasks, units, tasksByUnit] =
    await Promise.all([
      db.meeting.count({ where: meetingWhere }),
      db.meeting.count({ where: { ...meetingWhere, status: "CONFIRMED" } }),
      db.meeting.count({ where: { ...meetingWhere, status: "PENDING_APPROVAL" } }),
      db.task.count({ where: taskWhere }),
      db.task.count({ where: { ...taskWhere, status: "GREEN_DONE" } }),
      db.task.count({ where: { ...taskWhere, status: "RED_OVERDUE" } }),
      db.task.count({ where: { ...taskWhere, status: "YELLOW_DUE_SOON" } }),
      db.unit.findMany(),
      db.task.groupBy({ by: ["responsibleId"], _count: true, where: taskWhere })
    ]);

  const upcomingMeetings = await db.meeting.findMany({
    where: { ...meetingWhere, status: "CONFIRMED", date: { gte: new Date() } },
    orderBy: { date: "asc" },
    take: 5,
    include: { creator: true }
  });

  const myOpenTasks = await db.task.findMany({
    where: { responsibleId: user.id, doneAt: null },
    orderBy: { dueDate: "asc" },
    take: 5
  });

  // آمار مصوبات به تفکیک واحد (برای نمودار)
  const unitStats = await Promise.all(
    units.map(async (u) => ({
      unitId: u.id,
      unitName: u.name,
      color: u.colorHex,
      taskCount: await db.task.count({ where: { responsible: { unitId: u.id } } }),
      meetingCount: await db.meeting.count({ where: { attendees: { some: { user: { unitId: u.id } } } } })
    }))
  );

  return NextResponse.json({
    success: true,
    data: {
      totalMeetings,
      confirmedMeetings,
      pendingMeetings,
      totalTasks,
      doneTasks,
      overdueTasks,
      dueSoonTasks,
      upcomingMeetings,
      myOpenTasks,
      unitStats,
      orgWide
    }
  });
}
