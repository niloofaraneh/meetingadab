// این Recordها با Record<string, string> تایپ شده‌اند (نه Record<Role/...، string>) تا
// بتوان مستقیما مقدار رشته‌ای برگشتی از Prisma (چون SQLite از enum پشتیبانی نمی‌کند و
// فیلدها String هستند) را بدون کست دستی به این Recordها داد.

// برچسب فارسی نقش‌ها
export const ROLE_LABELS: Record<string, string> = {
  SUPER_ADMIN: "مدیرکل",
  CEO: "مدیرعامل",
  DEPUTY: "قائم مقام",
  UNIT_MANAGER: "مدیر واحد",
  SUPERVISOR: "سرپرست",
  STAFF: "کارمند"
};

// ترتیب سلسله‌مراتب نقش‌ها (عدد کمتر = دسترسی بالاتر)
export const ROLE_RANK: Record<string, number> = {
  SUPER_ADMIN: 0,
  CEO: 1,
  DEPUTY: 2,
  UNIT_MANAGER: 3,
  SUPERVISOR: 4,
  STAFF: 5
};

export const PRIORITY_LABELS: Record<string, string> = {
  LOW: "کم",
  NORMAL: "عادی",
  HIGH: "بالا",
  URGENT: "فوری"
};

export const PRIORITY_COLORS: Record<string, string> = {
  LOW: "#8a94a6",
  NORMAL: "#3574c4",
  HIGH: "#e0a72e",
  URGENT: "#d64545"
};

export const TASK_STATUS_LABELS: Record<string, string> = {
  GREEN_DONE: "اقدام شد",
  YELLOW_DUE_SOON: "نزدیک به مهلت",
  RED_OVERDUE: "گذشته از مهلت",
  IN_PROGRESS: "در حال انجام"
};

export const TASK_STATUS_COLORS: Record<string, string> = {
  GREEN_DONE: "#3f9e5e",
  YELLOW_DUE_SOON: "#e0a72e",
  RED_OVERDUE: "#d64545",
  IN_PROGRESS: "#3574c4"
};

export const MEETING_STATUS_LABELS: Record<string, string> = {
  PENDING_APPROVAL: "در انتظار تایید",
  CONFIRMED: "تایید شده",
  RESCHEDULE_PROPOSED: "زمان جایگزین پیشنهادی",
  REJECTED: "رد شده",
  DONE: "برگزار شده",
  CANCELED: "لغو شده"
};

export const MEETING_STATUS_COLORS: Record<string, string> = {
  PENDING_APPROVAL: "#e0a72e",
  CONFIRMED: "#3f9e5e",
  RESCHEDULE_PROPOSED: "#3574c4",
  REJECTED: "#d64545",
  DONE: "#8a94a6",
  CANCELED: "#8a94a6"
};

export const APP_NAME = "سامانه جلسات و صورتجلسات ادب‌ویزا";
export const APP_SHORT_NAME = "ادب‌ویزا";

// بازه‌های یادآوری اعلان قبل از جلسه/تسک (به دقیقه)
export const REMINDER_OFFSETS_MINUTES = {
  DAY_BEFORE: 24 * 60,
  ONE_HOUR: 60,
  FIVE_MINUTES: 5
};
