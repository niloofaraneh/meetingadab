import { Role } from "@/lib/enums";
import { ROLE_RANK } from "./constants";

export type SessionUser = {
  id: string;
  fullName: string;
  role: Role;
  unitId: string | null;
};

// آیا کاربر دسترسی مدیریتی کامل دارد (مدیرکل)
export function isSuperAdmin(user: SessionUser) {
  return user.role === "SUPER_ADMIN";
}

// آیا کاربر می‌تواند بدون نیاز به تاییدِ گام‌به‌گام برای دیگران تسک/جلسه اساین کند
// (مدیرکل، مدیرعامل و قائم مقام در کل سازمان - مدیر واحد/سرپرست فقط داخل واحد خودشان)
export function canAssignTo(actor: SessionUser, targetUnitId: string | null): boolean {
  if (isSuperAdmin(actor) || actor.role === "CEO" || actor.role === "DEPUTY") return true;
  if ((actor.role === "UNIT_MANAGER" || actor.role === "SUPERVISOR") && actor.unitId && actor.unitId === targetUnitId) {
    return true;
  }
  return false;
}

// دسترسی مدیریت واحدها/کاربران (فقط سطوح بالای سازمان)
export function canManageOrgStructure(user: SessionUser): boolean {
  return user.role === "SUPER_ADMIN" || user.role === "CEO";
}

// آیا کاربر می‌تواند گزارش‌ها و داشبورد کل سازمان (نه فقط واحد خودش) را ببیند
export function canViewOrgWideReports(user: SessionUser): boolean {
  return ["SUPER_ADMIN", "CEO", "DEPUTY"].includes(user.role);
}

export function isHigherOrEqualRank(a: Role, b: Role): boolean {
  return ROLE_RANK[a] <= ROLE_RANK[b];
}
