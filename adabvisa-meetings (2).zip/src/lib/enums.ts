/**
 * چون دیتابیس توسعه SQLite است و SQLite از enum پشتیبانی نمی‌کند، همه‌ی فیلدهای
 * وضعیتی در schema.prisma به‌صورت String تعریف شده‌اند. این فایل همان مقادیر را
 * به‌صورت type-safe برای استفاده در کل پروژه (به‌جای enum های @prisma/client) فراهم می‌کند.
 *
 * اگر روی MySQL/Postgres مستقر کردید و خواستید enum واقعی دیتابیس داشته باشید،
 * می‌توانید بعدا schema.prisma را به enum تبدیل کنید؛ چون مقادیر رشته‌ای دقیقا با
 * اسم‌های enum یکی هستند، هیچ تغییری در بقیه‌ی کد لازم نیست.
 */

export const Role = {
  SUPER_ADMIN: "SUPER_ADMIN",
  CEO: "CEO",
  DEPUTY: "DEPUTY",
  UNIT_MANAGER: "UNIT_MANAGER",
  SUPERVISOR: "SUPERVISOR",
  STAFF: "STAFF"
} as const;
export type Role = (typeof Role)[keyof typeof Role];

export const MeetingStatus = {
  PENDING_APPROVAL: "PENDING_APPROVAL",
  CONFIRMED: "CONFIRMED",
  RESCHEDULE_PROPOSED: "RESCHEDULE_PROPOSED",
  REJECTED: "REJECTED",
  DONE: "DONE",
  CANCELED: "CANCELED"
} as const;
export type MeetingStatus = (typeof MeetingStatus)[keyof typeof MeetingStatus];

export const AttendeeResponse = {
  PENDING: "PENDING",
  ACCEPTED: "ACCEPTED",
  REJECTED: "REJECTED",
  PROPOSED_NEW_TIME: "PROPOSED_NEW_TIME"
} as const;
export type AttendeeResponse = (typeof AttendeeResponse)[keyof typeof AttendeeResponse];

export const TaskPriority = {
  LOW: "LOW",
  NORMAL: "NORMAL",
  HIGH: "HIGH",
  URGENT: "URGENT"
} as const;
export type TaskPriority = (typeof TaskPriority)[keyof typeof TaskPriority];

export const TaskStatus = {
  GREEN_DONE: "GREEN_DONE",
  YELLOW_DUE_SOON: "YELLOW_DUE_SOON",
  RED_OVERDUE: "RED_OVERDUE",
  IN_PROGRESS: "IN_PROGRESS"
} as const;
export type TaskStatus = (typeof TaskStatus)[keyof typeof TaskStatus];

export const TaskApprovalStatus = {
  PENDING: "PENDING",
  ACCEPTED: "ACCEPTED",
  REJECTED: "REJECTED",
  RESCHEDULE_PROPOSED: "RESCHEDULE_PROPOSED"
} as const;
export type TaskApprovalStatus = (typeof TaskApprovalStatus)[keyof typeof TaskApprovalStatus];

export const NotificationChannel = {
  IN_APP: "IN_APP",
  SMS: "SMS",
  BOTH: "BOTH"
} as const;
export type NotificationChannel = (typeof NotificationChannel)[keyof typeof NotificationChannel];

export const NotificationType = {
  MEETING_INVITE: "MEETING_INVITE",
  MEETING_REMINDER_DAY: "MEETING_REMINDER_DAY",
  MEETING_REMINDER_HOUR: "MEETING_REMINDER_HOUR",
  MEETING_REMINDER_MINUTES: "MEETING_REMINDER_MINUTES",
  MEETING_STATUS_CHANGE: "MEETING_STATUS_CHANGE",
  TASK_ASSIGNED: "TASK_ASSIGNED",
  TASK_DUE_SOON: "TASK_DUE_SOON",
  TASK_OVERDUE: "TASK_OVERDUE",
  TASK_STATUS_CHANGE: "TASK_STATUS_CHANGE",
  GENERAL: "GENERAL"
} as const;
export type NotificationType = (typeof NotificationType)[keyof typeof NotificationType];
