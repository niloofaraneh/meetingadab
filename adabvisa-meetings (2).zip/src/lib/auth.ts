import { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";
import { db } from "./db";
import { normalizePhone } from "./utils";

export const authOptions: NextAuthOptions = {
  session: { strategy: "jwt" },
  pages: {
    signIn: "/login"
  },
  providers: [
    CredentialsProvider({
      name: "ورود با شماره موبایل",
      credentials: {
        phone: { label: "شماره موبایل", type: "text" },
        password: { label: "رمز عبور", type: "password" }
      },
      async authorize(credentials) {
        if (!credentials?.phone || !credentials?.password) return null;

        const phone = normalizePhone(credentials.phone);
        const user = await db.user.findUnique({
          where: { phone },
          include: { unit: true }
        });

        if (!user || !user.isActive) return null;

        const isValid = await bcrypt.compare(credentials.password, user.passwordHash);
        if (!isValid) return null;

        return {
          id: user.id,
          name: user.fullName,
          phone: user.phone,
          role: user.role,
          unitId: user.unitId,
          unitName: user.unit?.name ?? null,
          avatarUrl: user.avatarUrl ?? null
        } as any;
      }
    })
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        const u = user as any;
        token.id = u.id;
        token.role = u.role;
        token.unitId = u.unitId;
        token.unitName = u.unitName;
        token.avatarUrl = u.avatarUrl;
        token.phone = u.phone;
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        (session.user as any).id = token.id;
        (session.user as any).role = token.role;
        (session.user as any).unitId = token.unitId;
        (session.user as any).unitName = token.unitName;
        (session.user as any).avatarUrl = token.avatarUrl;
        (session.user as any).phone = token.phone;
      }
      return session;
    }
  },
  secret: process.env.NEXTAUTH_SECRET
};
