export function EmptyState({ title, description }: { title: string; description?: string }) {
  return (
    <div className="text-center py-12 text-navy-300">
      <p className="text-sm font-medium mb-1">{title}</p>
      {description && <p className="text-xs">{description}</p>}
    </div>
  );
}
