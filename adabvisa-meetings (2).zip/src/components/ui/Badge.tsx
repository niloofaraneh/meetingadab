import { cn } from "@/lib/utils";

export function Badge({
  children,
  color = "#3574c4",
  className
}: {
  children: React.ReactNode;
  color?: string;
  className?: string;
}) {
  return (
    <span
      className={cn("inline-flex items-center gap-1.5 text-xs font-medium px-2.5 py-1 rounded-full", className)}
      style={{ backgroundColor: `${color}1a`, color }}
    >
      <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: color }} />
      {children}
    </span>
  );
}
