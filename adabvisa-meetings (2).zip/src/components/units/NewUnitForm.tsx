"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/Button";

function flatten(units: any[], depth = 0): { id: string; name: string; depth: number }[] {
  return units.flatMap((u) => [{ id: u.id, name: u.name, depth }, ...flatten(u.children ?? [], depth + 1)]);
}

export function NewUnitForm({ parentOptions }: { parentOptions: any[] }) {
  const router = useRouter();
  const flatUnits = flatten(parentOptions);
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [colorHex, setColorHex] = useState("#1f2c4d");
  const [parentId, setParentId] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/units", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, code, colorHex, parentId: parentId || undefined })
      });
      const json = await res.json();
      if (!json.success) {
        setError(json.error ?? "خطا در ثبت واحد");
        return;
      }
      setName("");
      setCode("");
      router.refresh();
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      <input value={name} onChange={(e) => setName(e.target.value)} placeholder="نام واحد" className="w-full rounded-xl border border-navy-100 px-4 py-2.5 text-sm" required />
      <input value={code} onChange={(e) => setCode(e.target.value)} placeholder="کد (مثلا الف، ب، ...)" className="w-full rounded-xl border border-navy-100 px-4 py-2.5 text-sm" required />
      <div className="flex items-center gap-2">
        <input type="color" value={colorHex} onChange={(e) => setColorHex(e.target.value)} className="w-10 h-10 rounded-lg border border-navy-100" />
        <span className="text-xs text-navy-400">رنگ اختصاصی واحد در نمودارها</span>
      </div>
      <select value={parentId} onChange={(e) => setParentId(e.target.value)} className="w-full rounded-xl border border-navy-100 px-4 py-2.5 text-sm">
        <option value="">بدون واحد بالادستی (سطح اول)</option>
        {flatUnits.map((u) => (
          <option key={u.id} value={u.id}>{"— ".repeat(u.depth)}{u.name}</option>
        ))}
      </select>
      {error && <p className="text-sm text-status-danger">{error}</p>}
      <Button type="submit" disabled={loading}>{loading ? "در حال ثبت..." : "+ افزودن واحد"}</Button>
    </form>
  );
}
