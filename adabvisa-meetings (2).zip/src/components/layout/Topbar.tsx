"use client";
import { signOut } from "next-auth/react";
import { Avatar } from "@/components/ui/Avatar";
import { ROLE_LABELS } from "@/lib/constants";
import { Role } from "@/lib/enums";
import { useEffect, useState } from "react";
import Link from "next/link";

type NotificationItem = {
  id: string;
  title: string;
  message: string;
  isRead: boolean;
  createdAt: string;
};

export function Topbar({
  name,
  role,
  unitName,
  avatarUrl,
  userId
}: {
  name: string;
  role: Role;
  unitName: string | null;
  avatarUrl: string | null;
  userId: string;
}) {
  const [open, setOpen] = useState(false);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);

  useEffect(() => {
    fetch("/api/notifications")
      .then((r) => r.json())
      .then((res) => {
        if (res.success) setNotifications(res.data);
      });
  }, []);

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  async function markAllRead() {
    await fetch("/api/notifications", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ markAllRead: true })
    });
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
  }

  return (
    <header className="h-16 bg-white border-b border-navy-50 flex items-center justify-between px-6 sticky top-0 z-20">
      <div className="text-sm text-navy-400">
        {unitName ?? "سازمان ادب‌ویزا"} <span className="mx-2">/</span> {ROLE_LABELS[role]}
      </div>

      <div className="flex items-center gap-4">
        <div className="relative">
          <button
            onClick={() => setOpen((o) => !o)}
            className="relative w-9 h-9 rounded-full hover:bg-navy-50 flex items-center justify-center"
          >
            <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
              <path d="M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9" />
              <path d="M13.73 21a2 2 0 0 1-3.46 0" />
            </svg>
            {unreadCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 bg-status-danger text-white text-[10px] rounded-full w-4 h-4 flex items-center justify-center">
                {unreadCount}
              </span>
            )}
          </button>

          {open && (
            <div className="absolute left-0 mt-2 w-80 bg-white rounded-2xl shadow-card border border-navy-50 overflow-hidden">
              <div className="p-3 border-b border-navy-50 flex items-center justify-between">
                <span className="text-sm font-medium">اعلان‌ها</span>
                <button onClick={markAllRead} className="text-xs text-navy-400 hover:text-navy-700">
                  علامت‌گذاری همه به‌عنوان خوانده‌شده
                </button>
              </div>
              <div className="max-h-80 overflow-y-auto">
                {notifications.length === 0 && (
                  <p className="text-xs text-navy-300 text-center py-8">اعلانی وجود ندارد</p>
                )}
                {notifications.map((n) => (
                  <div key={n.id} className={`p-3 border-b border-navy-50 text-xs ${!n.isRead ? "bg-navy-50/60" : ""}`}>
                    <p className="font-medium text-navy-700 mb-0.5">{n.title}</p>
                    <p className="text-navy-400">{n.message}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <Link href={`/profile/${userId}`} className="flex items-center gap-2">
          <Avatar name={name} url={avatarUrl} size={34} />
          <span className="text-sm font-medium text-navy-800">{name}</span>
        </Link>

        <button
          onClick={() => signOut({ callbackUrl: "/login" })}
          className="text-xs text-navy-400 hover:text-status-danger"
        >
          خروج
        </button>
      </div>
    </header>
  );
}
