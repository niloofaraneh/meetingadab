"use client";
import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { Role } from "@/lib/enums";

const navItems = [
  { href: "/dashboard", label: "داشبورد", icon: "grid", roles: null },
  { href: "/meetings", label: "جلسات", icon: "calendar", roles: null },
  { href: "/minutes", label: "صورتجلسات", icon: "doc", roles: null },
  { href: "/tasks", label: "مصوبات و تسک‌ها", icon: "check", roles: null },
  { href: "/units", label: "واحدهای سازمانی", icon: "building", roles: ["SUPER_ADMIN", "CEO"] },
  { href: "/users", label: "پرسنل", icon: "users", roles: ["SUPER_ADMIN", "CEO"] },
  { href: "/settings", label: "تنظیمات", icon: "gear", roles: ["SUPER_ADMIN"] },
  { href: "/help", label: "راهنمای استفاده", icon: "help", roles: null }
];

const icons: Record<string, JSX.Element> = {
  grid: <path d="M4 4h6v6H4V4Zm10 0h6v6h-6V4ZM4 14h6v6H4v-6Zm10 0h6v6h-6v-6Z" />,
  calendar: <path d="M7 2v3M17 2v3M4 8h16M5 5h14a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1Z" />,
  doc: <path d="M7 3h7l5 5v13a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1ZM13 3v5h5" />,
  check: <path d="m5 13 4 4L19 7" />,
  building: <path d="M4 21V7l8-4 8 4v14M9 21v-6h6v6M4 21h16" />,
  users: <path d="M17 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2M11 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8ZM23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />,
  gear: <path d="M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9c.14.32.44.55.8.68.36.13.6.46.6.85" />,
  help: <path d="M9.09 9a3 3 0 1 1 5.83 1c0 2-3 3-3 3M12 17h.01M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Z" />
};

export function Sidebar({ role }: { role: Role }) {
  const pathname = usePathname();

  return (
    <aside className="w-64 shrink-0 h-screen sticky top-0 bg-navy-900 text-navy-100 flex flex-col">
      <div className="p-5 border-b border-white/10">
        <Image src="/images/logo.svg" alt="ادب‌ویزا" width={150} height={40} />
      </div>
      <nav className="flex-1 overflow-y-auto scrollbar-none py-4 px-3 space-y-1">
        {navItems
          .filter((item) => !item.roles || item.roles.includes(role))
          .map((item) => {
            const active = pathname?.startsWith(item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition",
                  active ? "bg-white/10 text-white font-medium" : "text-navy-200 hover:bg-white/5"
                )}
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                  {icons[item.icon]}
                </svg>
                {item.label}
              </Link>
            );
          })}
      </nav>
      <div className="p-4 text-[11px] text-navy-400 border-t border-white/10">
        نسخه ۱.۰ — سامانه داخلی ادب‌ویزا
      </div>
    </aside>
  );
}
