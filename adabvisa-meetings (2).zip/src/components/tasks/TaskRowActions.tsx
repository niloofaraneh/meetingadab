"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/Button";

export function TaskRowActions({
  taskId,
  approvalStatus,
  isDone
}: {
  taskId: string;
  approvalStatus: string;
  isDone: boolean;
}) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function act(body: any) {
    setLoading(true);
    try {
      await fetch(`/api/tasks/${taskId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      router.refresh();
    } finally {
      setLoading(false);
    }
  }

  if (approvalStatus === "PENDING") {
    return (
      <div className="flex gap-1.5">
        <Button variant="secondary" disabled={loading} onClick={() => act({ action: "respond", accept: true })}>تایید</Button>
        <Button variant="danger" disabled={loading} onClick={() => act({ action: "respond", accept: false })}>رد</Button>
      </div>
    );
  }

  if (!isDone) {
    return (
      <Button variant="secondary" disabled={loading} onClick={() => act({ action: "markDone" })}>
        انجام شد
      </Button>
    );
  }

  return null;
}
