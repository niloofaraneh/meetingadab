"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/Button";

export function AddTaskForm({
  minuteId,
  users
}: {
  minuteId?: string;
  users: { id: string; fullName: string }[];
}) {
  const router = useRouter();
  const [title, setTitle] = useState("");
  const [explanation, setExplanation] = useState("");
  const [responsibleId, setResponsibleId] = useState(users[0]?.id ?? "");
  const [priority, setPriority] = useState("NORMAL");
  const [jalaliDueDate, setJalaliDueDate] = useState("");
  const [isRecurring, setIsRecurring] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (!title || !responsibleId || !jalaliDueDate) {
      setError("موضوع، مسئول پیگیری و مهلت اجرا الزامی است.");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          explanation,
          minuteId,
          responsibleId,
          priority,
          jalaliDueDate,
          isRecurring
        })
      });
      const json = await res.json();
      if (!json.success) {
        setError(json.error ?? "خطا در ثبت مصوبه");
        return;
      }
      setTitle("");
      setExplanation("");
      router.refresh();
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="موضوع مصوبه" className="w-full rounded-xl border border-navy-100 px-4 py-2.5 text-sm" />
      <textarea value={explanation} onChange={(e) => setExplanation(e.target.value)} placeholder="توضیحات (اختیاری)" rows={2} className="w-full rounded-xl border border-navy-100 px-4 py-2.5 text-sm" />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <select value={responsibleId} onChange={(e) => setResponsibleId(e.target.value)} className="rounded-xl border border-navy-100 px-3 py-2.5 text-sm">
          {users.map((u) => <option key={u.id} value={u.id}>{u.fullName}</option>)}
        </select>
        <select value={priority} onChange={(e) => setPriority(e.target.value)} className="rounded-xl border border-navy-100 px-3 py-2.5 text-sm">
          <option value="LOW">اولویت کم</option>
          <option value="NORMAL">اولویت عادی</option>
          <option value="HIGH">اولویت بالا</option>
          <option value="URGENT">فوری</option>
        </select>
        <input value={jalaliDueDate} onChange={(e) => setJalaliDueDate(e.target.value)} placeholder="مهلت اجرا ۱۴۰۴/۰۳/۱۰" dir="ltr" className="rounded-xl border border-navy-100 px-3 py-2.5 text-sm" />
        <label className="flex items-center gap-2 text-sm text-navy-600 px-1">
          <input type="checkbox" checked={isRecurring} onChange={(e) => setIsRecurring(e.target.checked)} />
          تسک تکرارشونده
        </label>
      </div>
      {error && <p className="text-sm text-status-danger">{error}</p>}
      <Button type="submit" disabled={loading} variant="secondary">{loading ? "در حال ثبت..." : "+ افزودن مصوبه"}</Button>
    </form>
  );
}
