"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";

export function MeetingActions({
  meetingId,
  myResponse,
  isAttendee,
  canManage,
  status,
  hasMinute
}: {
  meetingId: string;
  myResponse: string | null;
  isAttendee: boolean;
  canManage: boolean;
  status: string;
  hasMinute: boolean;
}) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [proposeMode, setProposeMode] = useState(false);
  const [jalaliDate, setJalaliDate] = useState("");
  const [startTime, setStartTime] = useState("10:00");
  const [endTime, setEndTime] = useState("11:00");

  async function respond(response: "ACCEPTED" | "REJECTED" | "PROPOSED_NEW_TIME") {
    setLoading(true);
    try {
      const body: any = { response };
      if (response === "PROPOSED_NEW_TIME") {
        // در سمت سرور نیازمند ISO است؛ اینجا از endpoint جلسه که خودش jalali می‌پذیرد استفاده نشده،
        // پس این بخش را به‌عنوان یادداشت متنی ارسال می‌کنیم تا برگزارکننده هماهنگ کند.
        body.note = `زمان پیشنهادی: ${jalaliDate} ساعت ${startTime} تا ${endTime}`;
      }
      const res = await fetch(`/api/meetings/${meetingId}/respond`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      const json = await res.json();
      if (json.success) {
        router.refresh();
        setProposeMode(false);
      }
    } finally {
      setLoading(false);
    }
  }

  async function managerAction(action: "confirm" | "cancel") {
    setLoading(true);
    try {
      await fetch(`/api/meetings/${meetingId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action })
      });
      router.refresh();
    } finally {
      setLoading(false);
    }
  }

  async function createMinute() {
    router.push(`/minutes/new?meetingId=${meetingId}`);
  }

  return (
    <Card className="space-y-4">
      <h2 className="text-sm font-bold text-navy-800">اقدامات</h2>

      {isAttendee && status === "PENDING_APPROVAL" && !proposeMode && (
        <div className="flex flex-wrap gap-2">
          <Button variant="primary" disabled={loading} onClick={() => respond("ACCEPTED")}>تایید حضور</Button>
          <Button variant="danger" disabled={loading} onClick={() => respond("REJECTED")}>عدم امکان حضور</Button>
          <Button variant="secondary" disabled={loading} onClick={() => setProposeMode(true)}>پیشنهاد زمان دیگر</Button>
        </div>
      )}

      {proposeMode && (
        <div className="space-y-3 border-t border-navy-50 pt-4">
          <div className="grid grid-cols-3 gap-3">
            <input value={jalaliDate} onChange={(e) => setJalaliDate(e.target.value)} placeholder="۱۴۰۴/۰۳/۰۲" dir="ltr" className="rounded-xl border border-navy-100 px-3 py-2 text-sm" />
            <input type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} dir="ltr" className="rounded-xl border border-navy-100 px-3 py-2 text-sm" />
            <input type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} dir="ltr" className="rounded-xl border border-navy-100 px-3 py-2 text-sm" />
          </div>
          <div className="flex gap-2">
            <Button disabled={loading} onClick={() => respond("PROPOSED_NEW_TIME")}>ارسال پیشنهاد</Button>
            <Button variant="ghost" onClick={() => setProposeMode(false)}>انصراف</Button>
          </div>
        </div>
      )}

      {canManage && (
        <div className="flex flex-wrap gap-2 border-t border-navy-50 pt-4">
          {status !== "CONFIRMED" && status !== "CANCELED" && (
            <Button variant="secondary" disabled={loading} onClick={() => managerAction("confirm")}>تایید نهایی جلسه (دستی)</Button>
          )}
          {status !== "CANCELED" && (
            <Button variant="danger" disabled={loading} onClick={() => managerAction("cancel")}>لغو جلسه</Button>
          )}
          {!hasMinute && (
            <Button variant="secondary" onClick={createMinute}>ثبت صورتجلسه</Button>
          )}
        </div>
      )}
    </Card>
  );
}
